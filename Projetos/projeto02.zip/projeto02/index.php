<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu Principal</title>
</head>
<body>
    <h1>Menu principal</h1>
    <div>
    <ul>
        <li><a href="cadastro_agenda.html">Cadastrar contato</a></li>
        <li><a href="listar_agenda.php">Listar contatos</a></li>
    </ul>
    </div>
</body>
</html>